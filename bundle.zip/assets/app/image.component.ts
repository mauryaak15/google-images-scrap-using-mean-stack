import { Component } from '@angular/core';

@Component({
    selector: 'my-image',
    templateUrl: './image.component.html'
})
export class ImageComponent {
    
}